from setuptools import setup
setup(
    name='at.sellers.delays', # важно для разделения использовать только дефисы
    version='0.0.3',
    description='sellers delays cash Flow',
    url='https://gitlab.ozon.ru/cf_team/Delays',
    author='atrukhova',
    author_email='atrukhova@ozon.ru',
    license='superlicense',
    namespace_packages=['at_sellers_delays'],
    packages=['at_sellers_delays'], # Для разделения использовать только нижнее подчеркивание
    install_requires=[
        'datetime',
        'pandas',
        'numpy', 
        'vertica_python',
        'clickhouse_driver',
        'sqlalchemy',
        'psycopg2',
        'pymssql',
        'python-rake',
        'openpyxl',
        'xlsxwriter'
    ],
    package_dir={"at_sellers_delays": "data"}, # ключи словаря должны присутствовать в параметре packages (выше)
    keywords=['', ''],
)

