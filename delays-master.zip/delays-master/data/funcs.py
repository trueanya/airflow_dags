import sqlalchemy 
from sqlalchemy import create_engine  
import pandas as pd
import numpy as np
import vertica_python
import clickhouse_driver as chd
from clickhouse_driver.client import Client
import sys
import pymssql
import os

table_to = 'CF_team.at_sellers_delay_GMV'

def get_df_from_ch(sql, ch_creds):
    CH_CLIENT = ch_client = Client(**ch_creds)
    res = CH_CLIENT.execute(sql, with_column_types=True)
    df = pd.DataFrame(res[0])
    df.columns = [i[0] for i in res[1]]
    return df
    
def get_df_from_vertica(sql, conn_info):
    with vertica_python.connect(**conn_info) as vertica_connection:
        vertica_cursor = vertica_connection.cursor()
        vertica_cursor.execute(sql)
        vertica_data = vertica_cursor.fetchall()
        for i in range(0,len(vertica_data)):
            vertica_data[i]=tuple(vertica_data[i])
        vertica_df = pd.DataFrame(vertica_data)
        vertica_cursor.close()
        return vertica_df

def vertica_execute(sql, conn_info):
    vertica_conn = vertica_python.connect(**conn_info)
    cur = vertica_conn.cursor()
    try:
        runsql = cur.execute(sql)
    except Exception as e:
        exc = traceback.format_exc()
        log_entry('Ошибка при выполнении запроса на Vertica \n' + exc)
        print(log_entry)
        raise
    vertica_conn.commit()
    vertica_conn.close()

def insert_df_into_vertica(df : pd.DataFrame, table_name_vertica : str, conn_info, cols):
    with vertica_python.connect(**conn_info) as conn:
        cur = conn.cursor()
        file_name = "/tmp/{0}_tmp.text".format(table_name_vertica.split('.')[1])
        df.to_csv(file_name, sep=",", header=False, encoding='utf-8', index=False)
        print("Data was written to tmp csv file: {}".format(file_name))
        print("Copying data from local csv!")
        query = "COPY {0} ({1}) FROM LOCAL '{2}' DELIMITER','".format(
            table_name_vertica, ",".join(cols), file_name)
        print(query)
        cur.execute(query, buffer_size=65536)
        print("Rows loaded:", cur.fetchall())

        
def get_df_from_mssql(source_query, ms_conn):
    MS_CREDS = ms_conn
    ms_creds = f"mssql+pymssql://{MS_CREDS['user']}:{MS_CREDS['password']}@{MS_CREDS['host']}/zzzTemp"
    engine = create_engine(ms_creds)
    try:
        df_mssql = pd.read_sql(source_query, engine)
        return df_mssql

    except Exception as e:
        err = ('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        print(err)
  

