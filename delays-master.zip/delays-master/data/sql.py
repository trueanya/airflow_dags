sql_sripts = {
    
'sql_script_cubes' : """    DROP TABLE IF EXISTS actions;
                            CREATE LOCAL TEMPORARY TABLE actions ON COMMIT PRESERVE ROWS AS
                            SELECT FactDate as Date,
                                   ContractSupplyID as ContractID,
                                   SalesCommercial,
                                   ActionTypeID,
                                   ContractSupplyTypeID,
                                   ItemTypeID
                            FROM metazonbeeeye.Action AS t1
                            WHERE t1.FactDate >= 'start_date' AND t1.FactDate <= 'finish_date' AND ContractSupplyID is not null
                            ORDER BY ContractID, ContractSupplyTypeID, ItemTypeID
                            SEGMENTED BY HASH(ContractID, ContractSupplyTypeID, ItemTypeID) ALL NODES;

                            DROP TABLE IF EXISTS categories;
                            CREATE LOCAL TEMPORARY TABLE categories ON COMMIT PRESERVE ROWS AS
                            SELECT t2.ID AS ID,
                                   t3.Name as BU
                            FROM metazonbeeeye.ItemType AS t2
                            LEFT JOIN metazonbeeeye.Category AS t3 ON t2.Category1ID = t3.ID
                            ORDER BY ID
                            SEGMENTED BY HASH(ID) ALL NODES;

                            DROP TABLE IF EXISTS action_types;
                            CREATE LOCAL TEMPORARY TABLE action_types ON COMMIT PRESERVE ROWS AS
                            SELECT at.ID AS ID,
                                   at2.Name as act_type
                            FROM  metazonbeeeye.actiontype at
                            left join metazonbeeeye.actiontype at2 ON at2.ID = at.ParentActionTypeID
                            ORDER BY ID
                            SEGMENTED BY HASH(ID) ALL NODES;
                            
                            DROP TABLE IF EXISTS itog;
                            CREATE LOCAL TEMPORARY TABLE itog ON COMMIT PRESERVE ROWS AS
                            SELECT  a.Date,
                                    BU,
                                    a.ContractID,
                                    SUM(SalesCommercial) AS Sales_GMV
                            FROM actions AS a
                            JOIN action_types at ON a.ActionTypeID = at.ID
                            LEFT JOIN categories c ON a.ItemTypeID = c.ID
                            LEFT JOIN metazonbeeeye.ContractSupplyType ct ON ct.ID = a.ContractSupplyTypeID
                            WHERE act_type ='Продажи'
                            AND ct.Name = 'Договор комиссии'
                            AND BU IN ( 'Apparel',
                                                'Auto&Moto',
                                                'Books',
                                                'DIY',
                                                'Hobbies&Creativity',
                                                'Kids Goods&Sport',
                                                'Furniture',
                                                'Health&Beauty',
                                                'Household',
                                                'Laptops & Computers',
                                                'Major Domestic Appliances',
                                                'Miscellaneous accessories',
                                                'Small Domestic Appliances',
                                                'Smartphones & Tablets',
                                                'Sport',
                                                'TV, audio, Hi-Fi & other electronics',
                                                'Zoo',
                                                'Cotton&Paper',
                                                'Fabric&Home',
                                                'Hygiene',
                                                'Pharmacy',
                                                'BabyFood',
                                                'Beverages',
                                                'DryFood',
                                                'School&Stationery&Equipment',
                                                'Toys')
                            GROUP BY BU,ContractID,Date;
                       
                            TRUNCATE TABLE CF_team.at_gmv_for_delays;
                            INSERT INTO CF_team.at_gmv_for_delays
                            SELECT * FROM itog; """ ,
    
'get_df_from_olap' : 'SELECT * FROM CF_team.at_gmv_for_delays' ,
    
'sql_get_bu' : '''SELECT DISTINCT MacroBU, BU FROM cash_mp.cash_result WHERE BU <> 'Total' ''',
    
'sql_script_final' : '''DROP TABLE IF EXISTS CF_team.at_final_delay_wo_gmv;
                        CREATE TABLE  CF_team.at_final_delay_wo_gmv (
                        metazon_contract_id int,
                        BU varchar,
                        Date DATETIME,
                        delay int,     
                        MacroBU varchar);''' ,   
'sql_get_delay' : '''select distinct metazon_contract_id, delay, Date_Time from  zzzTemp.dbo.VB_seller_delays;''',
   
'sql_ids' : '''SELECT DISTINCT ContractID, BU, Date FROM CF_team.at_gmv_for_delays ''',

'get_columns_names' : ''' SELECT  column_name
 FROM columns WHERE table_schema = 'CF_team' AND table_name = 'at_final_delay_wo_gmv';''',
'sql_res' : '''SELECT * FROM CF_team.at_sellers_delays''',
}
