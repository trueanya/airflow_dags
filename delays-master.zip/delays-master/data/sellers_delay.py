def sellers_delay_update(conn_info_vertica, conn_info_click,conn_info_ms, AZUREAPP_TENANT, AZUREAPP_CLIENT,AZUREAPP_SECRET, ACCOUNT_LOGIN, ACCOUNT_PASSWORD, team_id, channel_id, sharepoint_drive_id, sharepoint_path):
    from at_sellers_delays.sql import sql_sripts as sql
    import datetime
    import pandas as pd
    from pandas import ExcelWriter
    import xlsxwriter
    import numpy as np
    import vertica_python as vp
    import clickhouse_driver as chd
    import sys
    import os
    import logging
    from at_sellers_delays import funcs as f
    from at_sellers_delays import bot_funcs as bf
    
    current_dir_path = os.path.dirname(os.path.abspath(__file__))
    clickhouse_connect = chd.connect(**conn_info_click)
    vertica_connect = vp.connect(**conn_info_vertica)
    conn_info_ms = conn_info_ms
    logger = logging.getLogger()
    proxy_dict = {'http': '', 'https': ''}
    
    MacroBU = f.get_df_from_ch(sql['sql_get_bu'], conn_info_click).rename(columns={0:'MacroBU', 1:'BU'})
    print('getting_delays...',datetime.datetime.now())
    seller_delays = f.get_df_from_mssql(sql['sql_get_delay'], conn_info_ms)
    seller_delays['Date_Time'] = seller_delays['Date_Time'].dt.date
    seller_delays['metazon_contract_id'] = pd.to_numeric(seller_delays['metazon_contract_id'], downcast="integer")
    start_date = f'''{seller_delays['Date_Time'].min()}'''
    finish_date = f'''{seller_delays['Date_Time'].max()}'''
    gmv_query = (sql['sql_script_cubes']).replace('start_date', start_date).replace('finish_date', finish_date)
    print('executing sql_script_cubes...', datetime.datetime.now()) #От начала скрипта до этого места ~ 8 мин
    f.vertica_execute(gmv_query, conn_info_vertica) 
    print('getting ids...', datetime.datetime.now()) #От sql_script_cubes до этого места ~ 10 мин
    ids =  f.get_df_from_vertica(sql['sql_ids'],conn_info_vertica).rename(columns={0:'metazon_contract_id', 1:'BU', 2 :'Date_Time'}).dropna()
    seller_delays['Date_Time'] = pd.to_datetime(seller_delays['Date_Time'])
    print('merging...',datetime.datetime.now()) #От getting ids до этого места > 15 мин
    delays_dist = ids.merge(seller_delays,
                                        how = "inner",
                                        left_on = ['metazon_contract_id','Date_Time'],
                                        right_on = ['metazon_contract_id','Date_Time'])
    
    delays_dist['metazon_contract_id'] = pd.to_numeric(delays_dist['metazon_contract_id'], downcast="integer")
    to_vertica = delays_dist.merge(MacroBU,
                                       how = "left",
                                       left_on = ['BU'],
                                       right_on = ['BU']).fillna('wo_BU').rename(columns={2: 'Date'})

    to_vertica['delay'] = to_vertica['delay'].apply(lambda x: x if x != 11 else 'special').astype(str)
    print('executing sql_script_final', datetime.datetime.now())
    f.vertica_execute(sql['sql_script_final'], conn_info_vertica)
    columns =  f.get_df_from_vertica(sql['get_columns_names'], conn_info_vertica)
    f.insert_df_into_vertica(to_vertica, 'CF_team.at_final_delay_wo_gmv', conn_info_vertica,columns[0])
    print("Making excel file...")
    result = f.get_df_from_vertica(sql['sql_res'], conn_info_vertica)
    print("Posting excel file...")
    bearer_token = bf.get_teams_bearer_token(AZUREAPP_TENANT,                          AZUREAPP_CLIENT,AZUREAPP_SECRET, ACCOUNT_LOGIN, ACCOUNT_PASSWORD)
    print("Test_message, bearer_token")
    #message = 'hi'
    #bf.post_to_teams_channel_msg(message, bearer_token, team_id, channel_id, proxy=proxy_dict)
    bf.post_to_teams_channel_attach(result, bearer_token, team_id, channel_id,    sharepoint_drive_id, sharepoint_path, f'Отсрочки по селлерам за {datetime.datetime.strftime(datetime.datetime.now(), "%Y-%m-%d")}', mode='large file', proxy=proxy_dict)
    print('End',datetime.datetime.now())
