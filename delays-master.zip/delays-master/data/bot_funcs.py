import logging
from urllib.parse import quote
import json
import requests
import os
import pandas as pd
from pandas import ExcelWriter
import xlsxwriter
import numpy as np

proxy_dict = {'http': '', 'https': ''}
def get_teams_bearer_token(azureapp_tenant, azureapp_client, azureapp_secret, account_login, account_password, proxy=proxy_dict):
    logger = logging.getLogger()
    proxy_dict = {'http': '', 'https': ''}
    response_auth = requests.post(
        url="https://login.microsoftonline.com/{}/oauth2/v2.0/token".format(azureapp_tenant),
        headers={
            "Content-Type": "application/x-www-form-urlencoded"
        },
        data={
            "client_id": azureapp_client,
            "client_secret": azureapp_secret,
            "scope": "ChannelMessage.Send",
            "grant_type": "password",
            "username": account_login,
            "password": account_password
        },
        proxies=proxy
    )
    if response_auth.status_code // 100 != 2:
        logger.warning(response_auth.text)
        return None
    else:
        return response_auth.json()['access_token']
 
def post_to_teams_channel_attach(result, bearer_token, team_id, channel_id, sharepoint_drive_id, sharepoint_path, message='', mode='file', proxy=proxy_dict):
    logger = logging.getLogger()
    proxy_dict = {'http': '', 'https': ''}
    """
    Отправка сообщения с прикрепленным изображением/файлом
    (!) ВНИМАНИЕ: Для отправки сообщения бот должен находиться в команде
 
    ОБЯЗАТЕЛЬНЫЕ ПАРАМЕТРЫ
        path - string - путь к файлу для загрузки
        bearer_token - string - авторизационный токен     
        team_id - string - ID команды MS Teams      groupId=2d4bbfd3-8ee4-4092-9fd2-5a76cc211f1e
        channel_id - string - ID канала MS Teams g  19:f7e6fb0ce45546b49a6664c4ad453982 
        sharepoint_drive_id - string - ID хранилища sharepoint,             id=%2Fpersonal%2Fatrukhova_ozon_ru%2FDocuments%2FCF_team
        sharepoint_path - string - путь для файла в хранилище Sharepoint
 
    ДОПОЛНИТЕЛЬНЫЕ ПАРАМЕТРЫ
        message - string - текст сообщения - по умолчанию ''
        mode - string - 'file', 'large file' (для файлов более 4 Mb) или 'image' - по умолчанию 'file'
        proxy - dict - словарь с прокси для requests - по умолчанию default из ozon_bots
 
    ВОЗВРАЩАЕТ
        status_code - int - статус запроса на отправку сообщения
    """
 
    _etag = ""
    _fileUrl = ""
    _fileName = ""
    _fileThumbnail = ""

    folder = '/tmp'
    filename = f'sellers_delays.xlsx'
    filepath = os.path.join(folder, filename)
    print(filepath)
    writer = pd.ExcelWriter(filepath, engine='xlsxwriter')
    result.to_excel(writer)
    writer.save()
    
    # 1 - загрузка файла в SharePoint
    if mode == "file":
        _data = open(filepath, 'rb').read()
 
        _response = requests.put(
            url=f"https://graph.microsoft.com/v1.0/drives/{sharepoint_drive_id}/items/root:/{sharepoint_path}:/content",
            headers={
                "Content-Type": "application/binary",
                "Authorization": f"Bearer {bearer_token}",
            },
            data=_data
        )
        print(_response)

 
        _response_path = requests.get(
            url=f"https://graph.microsoft.com/v1.0/drives/{_response.json()['parentReference']['driveId']}",
            headers={"Authorization": f"Bearer {bearer_token}"}
        )
 
        _etag = _response.json()['eTag']
        _etag = _etag[_etag.find("{") + 1:_etag.rfind("}")]
        _fileUrl = _response_path.json()['webUrl'] + quote(sharepoint_path)
        _fileName = _response.json()['name']
        print(_data,_response)

    elif mode == "large file":
 
        # инициализация сессии
        _response = requests.post(
            url=f"https://graph.microsoft.com/v1.0/drives/{sharepoint_drive_id}/items/root:/{sharepoint_path}:/createUploadSession",
            headers={"Authorization": f"Bearer {bearer_token}"}
        )
 
        # загрузка файла чанками в сессию
        with open(filepath, 'rb') as f:
            total_file_size = os.path.getsize(filepath)
            chunk_size = 327680
            chunk_number = total_file_size // chunk_size
            chunk_leftover = total_file_size - chunk_size * chunk_number
 
            i = 0
            while True:
                chunk_data = f.read(chunk_size)
                start_index = i * chunk_size
                end_index = start_index + chunk_size
                if not chunk_data:
                    break
                if i == chunk_number:
                    end_index = start_index + chunk_leftover
 
                _upload_response = requests.put(
                    url=_response.json()['uploadUrl'],
                    headers={
                        'Content-Length': '{}'.format(chunk_size),
                        'Content-Range': 'bytes {}-{}/{}'.format(start_index, end_index - 1, total_file_size)
                    },
                    data=chunk_data
                )
                i += 1
 
        _response_path = requests.get(
            url=f"https://graph.microsoft.com/v1.0/drives/{_upload_response.json()['parentReference']['driveId']}",
            headers={"Authorization": f"Bearer {bearer_token}"}
        )
 
        _etag = _upload_response.json()['eTag']
        _etag = _etag[_etag.find("{") + 1:_etag.rfind("}")]
        _fileUrl = _response_path.json()['webUrl'] + quote(sharepoint_path)
        _fileName = _upload_response.json()['name']

    else:
        logger.warning(
            "Неизвестное значение параметра mode! Используйте 'file', 'large file' (для файлов более 4 Mb) или 'image'")
        return -1
 
    # 2 - отправка в MS Teams
    if mode == "file" or mode == "large file":
        _response = requests.post(
            url=f"https://graph.microsoft.com/v1.0/teams/{team_id}/channels/{channel_id}@thread.tacv2/messages",
            headers={
                "Authorization": f"Bearer {bearer_token}",
                "Content-type": "application/json"
            },
            data=json.dumps(
                {
                    "body": {
                        "contentType": "html",
                        "content": f"{message}<br><attachment id=\"{_etag}\"></attachment>"
                    },
                    "attachments": [
                        {
                            "id": _etag,
                            "contentType": "reference",
                            "contentUrl": _fileUrl,
                            "name": _fileName
                        }
                    ]
                }
            ),
            proxies=proxy
        )
 
        if _response.status_code // 100 != 2:
            logger.warning(_response.text)
        return _response.status_code
    elif mode == "image":
        _response = requests.post(
            url=f"https://graph.microsoft.com/v1.0/teams/{team_id}/channels/{channel_id}@thread.tacv2/messages",
            headers={
                "Authorization": f"Bearer {bearer_token}",
                "Content-type": "application/json"
            },
            data=json.dumps(
                {
                    "body": {
                        "contentType": "html",
                        "content": f"{message}<br><img src=\"{_fileThumbnail}\" alt=\"{_fileName}\"/><attachment id=\"{_etag}\"></attachment>"
                    },
                    "attachments": [
                        {
                            "id": _etag,
                            "contentType": "reference",
                            "contentUrl": _fileUrl,
                            "name": _fileName
                        }
                    ]
                }
            ),
            proxies=proxy
        )
 
        if _response.status_code // 100 != 2:
            logger.warning(_response.text)
        return _response.status_code
    else:
        logger.warning(
            "Неизвестное значение параметра mode! Используйте 'file', 'large file' (для файлов более 4 Mb) или 'image'")
        return -1
        
def post_to_teams_channel_msg(message, bearer_token, team_id, channel_id, proxy=proxy_dict):
    """
    Отправка сообщения в канал MS Teams
    (!) ВНИМАНИЕ: Для отправки сообщения бот должен находиться в команде
    ОБЯЗАТЕЛЬНЫЕ ПАРАМЕТРЫ
        html - string - сообщение с HTML форматированием
        bearer_token - string - авторизационный токен
        team_id - string - ID команды MS Teams
        channel_id - string - ID канала MS Teams
 
    ДОПОЛНИТЕЛЬНЫЕ ПАРАМЕТРЫ
        proxy - dict - словарь с прокси для requests - по умолчанию default из ozon_bots
 
    ВОЗВРАЩАЕТ
        status_code - int - статус запроса на отправку сообщения
    """
    response_message = requests.post(
        url=f"https://graph.microsoft.com/v1.0/teams/{team_id}/channels/{channel_id}@thread.tacv2/messages",
        headers={
            "Authorization": f"Bearer {bearer_token}",
            "Content-type": "application/json"
        },
        data=json.dumps(
            {
                "body": {
                    "content": message
                }
            }
        ),
        proxies=proxy
    )
    if response_message.status_code // 100 != 2:
        logger.warning(response_message.text)
    return response_message.status_code
