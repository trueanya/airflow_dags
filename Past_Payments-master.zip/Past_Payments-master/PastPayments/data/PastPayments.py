def payments(conn_info_ms):
    import pandas as pd
    import numpy as np
    import pyodbc
    from sqlalchemy import create_engine 

    #ms_creds = f"mssql+pymssql://{conn_info_ms['user']}:{conn_info_ms['password']}@{conn_info_ms['host']}/zzzTemp"
    #engine = create_engine(ms_creds)
    
    def get_ms_params(conn_info_ms):
        PARAMS = ['DRIVER={ODBC Driver 17 for SQL Server}',
                  'SERVER=bidb.o3.ru',  # укажите сервер, логин, пароль и базу данных
                  f'UID={conn_info_ms["user"]}',
                  f'PWD={conn_info_ms["password"]}',
                  'DATABASE=zzzTemp'
              ]
        MSSQL_CONNECTION_STRING = ';'.join(PARAMS)
        return MSSQL_CONNECTION_STRING

    MSSQL_CONNECTION_STRING = get_ms_params(conn_info_ms)

    sql = {
    'main' :
    '''
    DECLARE @Date1_orig date = dateadd(dd, -365, getdate())
    DECLARE @Date2_orig date = getdate()
    DECLARE @Date1 date = iif (datepart(dw,@Date1_orig) = 2, cast(dateadd(dd, -3, @Date1_orig) as date), cast(dateadd(dd, -1, @Date1_orig) as date) )--'2020-01-01' -- Начало периода  если пн=2
    DECLARE @Date2 date = iif (datepart(dw,@Date2_orig) = 2, cast(dateadd(dd, -3, @Date2_orig) as date), cast(dateadd(dd, -1, @Date2_orig) as date) )  -- Конец периода

    DROP TABLE IF EXISTS #operation;
    SELECT DISTINCT
                    Amount,
                    DocumentID
    INTO #operation
    FROM METAZON_RO.Metazon.dbo.BankOperation O
    WHERE O.DocumentID IN (SELECT originalDocumentID
                        FROM Reporting_DataMart.CCF.mb_CF_out_past)
    AND O.DocDate > @Date1
    AND O.DocDate < @Date2
    AND O.PayerINN in ('7704217370', '6949003359')
    AND O.Amount < 0;

    DROP TABLE IF EXISTS #ids1;
    WITH sum AS (
    SELECT SUM(abs(P.Amount)) AS Amount,
        originalDocumentID,
        O.Amount as OperationAmount
    FROM Reporting_DataMart.CCF.mb_CF_out_past P
    LEFT JOIN #operation  O ON O.DocumentID = P.originalDocumentID
    GROUP BY originalDocumentID,
            O.Amount
    ),
    poblem_ids AS (
        SELECT p.originalDocumentID,
            p.DocumentType,
            p.DocumentID,
            p.Amount,
            O.Amount AS OperationAmount
        FROM  Reporting_DataMart.CCF.mb_CF_out_past p
        LEFT JOIN sum s ON s.originalDocumentID = p.originalDocumentID
        LEFT JOIN #operation  O ON O.DocumentID = P.originalDocumentID
        WHERE (abs(s.Amount) > abs(s.OperationAmount) OR  p.DocDate > p.PaymentDate)

    )
    SELECT originalDocumentID,
        DocumentType,
        DocumentID,
        OperationAmount,
        Amount
    INTO #ids1
    FROM poblem_ids;

    DROP TABLE IF EXISTS #problem_ids_2;
    SELECT  originalDocumentID,
            count(DISTINCT DocumentType) AS cnt
    INTO #problem_ids_2
    FROM #ids1 i
    GROUP BY i.originalDocumentID
    HAVING count(DISTINCT DocumentType) > 1;

    DROP TABLE IF EXISTS #final_work;
    SELECT DISTINCT p.originalDocumentID,
                    p.DocumentType,
                    p.DocumentID,
                    p.Amount,
                    i1.OperationAmount,
                    CASE WHEN p.DocumentID IN (SELECT ID FROM  METAZON_RO.METAZON.dbo.DocumentLst D
                                            WHERE ID IN (SELECT DocumentID FROM Reporting_DataMart.CCF.mb_CF_out_past WHERE DocumentType LIKE '%Счет%')
                                            AND D.Date > @Date1
                                            AND D.Date < @Date2
                                            AND (Descript LIKE '%Предоплата%' OR  Descript LIKE '%Prepayment%' OR  Descript LIKE '%Preayment%'  OR  Descript LIKE '%VO11100%')AND (Descript NOT LIKE '%удержана предоплата%'))
                    THEN 1 ELSE 0 END Prepayment_description
    INTO #final_work
    FROM Reporting_DataMart.CCF.mb_CF_out_past p
    LEFT JOIN #problem_ids_2 ON #problem_ids_2.originalDocumentID = p.originalDocumentID
    LEFT JOIN #ids1 i1 ON i1.DocumentID  = p.DocumentID
    WHERE p.originalDocumentID IN (SELECT originalDocumentID FROM #problem_ids_2)
    ORDER BY originalDocumentID;


    DROP TABLE IF EXISTS #drop_nakl;
    WITH sum AS (
    SELECT sum(Amount) as sum ,
        originalDocumentID
    FROM #final_work
    WHERE  DocumentType LIKE '%Счет%' AND Prepayment_description = 1
    GROUP BY originalDocumentID
    )
    SELECT DISTINCT sum.*,
                    OperationAmount
    INTO #drop_nakl
    FROM  sum
    JOIN  #final_work ON sum.originalDocumentID = #final_work.originalDocumentID
    WHERE OperationAmount = sum
    ;

    DROP TABLE IF EXISTS #new_sum;
    WITH left_docs AS (
    SELECT DISTINCT f.*,
        p.DocDate,
        p.PaymentDate
    FROM #final_work f
    LEFT JOIN Reporting_DataMart.CCF.mb_CF_out_past p ON f.originalDocumentID = p.originalDocumentID AND f.DocumentID = p.DocumentID
    WHERE f.DocumentType LIKE '%Счет%' AND f.originalDocumentID NOT IN (SELECT originalDocumentID FROM #drop_nakl)
    ),
    sum AS (
    SELECT originalDocumentID,
        sum(Amount) AS Amount
    FROM left_docs
    WHERE DocDate <= PaymentDate
    GROUP BY originalDocumentID)
    SELECT DISTINCT left_docs.DocumentID,
                    sum.originalDocumentID,
                    sum.Amount,
                    f.OperationAmount
    INTO #new_sum
    FROM sum
    LEFT JOIN #final_work f ON sum.originalDocumentID = f.originalDocumentID
    LEFT JOIN left_docs ON sum.originalDocumentID = left_docs.originalDocumentID
    WHERE sum.Amount = f.OperationAmount AND DocDate <= PaymentDate;
    ;

    DROP TABLE IF EXISTS #schet_nakl;
    WITH init AS (
    SELECT sum(f.Amount) as sum ,
        f.originalDocumentID
    FROM #final_work f
    LEFT JOIN Reporting_DataMart.CCF.mb_CF_out_past p ON f.originalDocumentID = p.originalDocumentID and f.DocumentID = p.DocumentID
    WHERE f.originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID
                                    FROM #drop_nakl)
        AND f.originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID
                                        FROM #new_sum)
        AND  DocDate <= PaymentDate
    GROUP BY f.originalDocumentID)
    SELECT DISTINCT init.*,
                    OperationAmount
    INTO #schet_nakl
    FROM  init
    left JOIN  #final_work ON init.originalDocumentID = #final_work.originalDocumentID
    WHERE OperationAmount = sum;

    DROP TABLE IF EXISTS #itog;
    WITH itog AS (
    SELECT DISTINCT *
    FROM Reporting_DataMart.CCF.mb_CF_out_past
    WHERE originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #drop_nakl)
        AND originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #new_sum)
        AND originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #schet_nakl)
    UNION
    SELECT DISTINCT *
    FROM Reporting_DataMart.CCF.mb_CF_out_past
    WHERE originalDocumentID  IN (SELECT DISTINCT originalDocumentID FROM #drop_nakl)
        AND originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #new_sum)
        AND originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #schet_nakl)
        AND DocumentType LIKE '%Счет%' AND  DocDate <= PaymentDate
    UNION
    SELECT DISTINCT *
    FROM Reporting_DataMart.CCF.mb_CF_out_past
    WHERE originalDocumentID  IN (SELECT DISTINCT originalDocumentID FROM #new_sum)
        AND DocumentID IN (SELECT DISTINCT DocumentID FROM #new_sum)
        AND originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #drop_nakl)
        AND originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #schet_nakl)
        AND  DocDate <= PaymentDate
    UNION
    SELECT DISTINCT *
    FROM Reporting_DataMart.CCF.mb_CF_out_past
    WHERE originalDocumentID  NOT IN (SELECT DISTINCT originalDocumentID FROM #new_sum)
        AND DocumentID  NOT IN (SELECT DISTINCT DocumentID FROM #new_sum)
        AND originalDocumentID NOT IN (SELECT DISTINCT originalDocumentID FROM #drop_nakl)
        AND originalDocumentID  IN (SELECT DISTINCT originalDocumentID FROM #schet_nakl)
        AND  DocDate <= PaymentDate
    )
    SELECT f.*
    into #itog
    FROM itog f
    LEFT JOIN Reporting_DataMart.CCF.mb_CF_out_past p ON f.originalDocumentID = p.originalDocumentID and f.DocumentID = p.DocumentID
    ;


    DECLARE @Data1_orig date = dateadd(dd, -365, getdate())
    DECLARE @Data2_orig date = dateadd(dd, -180, getdate())
    DECLARE @Data1 date = iif (datepart(dw,@Data1_orig) = 2, cast(dateadd(dd, -3, @Data1_orig) as date), cast(dateadd(dd, -1, @Data1_orig) as date) )--'2020-01-01' -- Начало периода  если пн=2
    DECLARE @Data2 date = iif (datepart(dw,@Data2_orig) = 2, cast(dateadd(dd, -3, @Data2_orig) as date), cast(dateadd(dd, -1, @Data2_orig) as date) )  -- Конец периода

    DECLARE @Date3_orig date = dateadd(dd, -180, getdate())
    DECLARE @Date4_orig date = getdate()
    DECLARE @Date3 date = iif (datepart(dw,@Date3_orig) = 2, cast(dateadd(dd, -3, @Date3_orig) as date), cast(dateadd(dd, -1, @Date3_orig) as date) )--'2020-01-01' -- Начало периода  если пн=2
    DECLARE @Date4 date = iif (datepart(dw,@Date4_orig) = 2, cast(dateadd(dd, -3, @Date4_orig) as date), cast(dateadd(dd, -1, @Date4_orig) as date) )  -- Конец периода


    DROP TABLE IF EXISTS #ids;
    SELECT ID
    into #ids
    FROM  METAZON_RO.METAZON.dbo.DocumentLst D
    WHERE D.ID IN (SELECT DISTINCT DocumentID
                FROM Reporting_DataMart.CCF.mb_CF_out_past p
                WHERE p.DocDate >= @Data1 AND p.DocDate <= @Data2)
    AND D.Date >= @Data1
    AND D.Date <= @Data2
    AND (Descript LIKE '%Предоплата%'
        OR  Descript LIKE '%Prepayment%'
        OR  Descript LIKE '%Preayment%'
        OR  Descript LIKE '%VO11100%')
    AND (Descript NOT LIKE '%удержана предоплата%' ) ;

    DROP TABLE IF EXISTS #ids2;
    SELECT ID
    into #ids2
    FROM  METAZON_RO.METAZON.dbo.DocumentLst D
    WHERE D.ID IN (SELECT DISTINCT DocumentID FROM Reporting_DataMart.CCF.mb_CF_out_past p WHERE p.DocDate >= @Date3 AND p.DocDate <= @Date4)
    AND D.Date >= @Date3
    AND D.Date <= @Date4
    AND (Descript LIKE '%Предоплата%'
        OR  Descript LIKE '%Prepayment%'
        OR  Descript LIKE '%Preayment%'
        OR  Descript LIKE '%VO11100%')
    AND (Descript NOT LIKE '%удержана предоплата%' ) ;

    DROP TABLE IF EXISTS #prep;
    WITH A AS (
    SELECT * FROM  #ids
    UNION
    SELECT * FROM  #ids2)
    SELECT *
    INTO #prep
    FROM A;

    DROP TABLE IF EXISTS #col;
    SELECT DocumentID,
    CASE WHEN p.DocumentID IN (SELECT * FROM #prep)
    THEN 1
    ELSE 0 END Prepayment_description
    into #col
    FROM Reporting_DataMart.CCF.mb_CF_out_past p;

    DROP TABLE IF EXISTS zzzTemp.PastPayments_new;
    SELECT DISTINCT i.*,
                    c.Prepayment_description
    INTO zzzTemp.PastPayments_new
    FROM #itog i
    LEFT JOIN #col c ON c.DocumentID = i.DocumentID; 
    ''',
    'future': '''
    
DECLARE @Data1_orig date = dateadd(dd, -365, getdate())
DECLARE @Data2_orig date = dateadd(dd, -180, getdate())
DECLARE @Data1 date = iif (datepart(dw,@Data1_orig) = 2, cast(dateadd(dd, -3, @Data1_orig) as date), cast(dateadd(dd, -1, @Data1_orig) as date) )--'2020-01-01' -- Начало периода  если пн=2
DECLARE @Data2 date = iif (datepart(dw,@Data2_orig) = 2, cast(dateadd(dd, -3, @Data2_orig) as date), cast(dateadd(dd, -1, @Data2_orig) as date) )  -- Конец периода

DROP TABLE IF EXISTS #ids;
SELECT ID
into #ids
FROM  METAZON_RO.METAZON.dbo.DocumentLst D
WHERE D.ID IN (SELECT DISTINCT DocumentID
               FROM Reporting_DataMart.CCF.mb_CF_out_future p
               WHERE p.DocDate >= @Data1 AND p.DocDate <= @Data2)
AND D.Date >= @Data1
AND D.Date <= @Data2
AND (Descript LIKE '%Предоплата%'
     OR  Descript LIKE '%Prepayment%'
     OR  Descript LIKE '%Preayment%'
     OR  Descript LIKE '%VO11100%')
AND (Descript NOT LIKE '%удержана предоплата%') ;


DECLARE @Date3_orig date = dateadd(dd, -180, getdate())
DECLARE @Date4_orig date = getdate()
DECLARE @Date3 date = iif (datepart(dw,@Date3_orig) = 2, cast(dateadd(dd, -3, @Date3_orig) as date), cast(dateadd(dd, -1, @Date3_orig) as date) )--'2020-01-01' -- Начало периода  если пн=2
DECLARE @Date4 date = iif (datepart(dw,@Date4_orig) = 2, cast(dateadd(dd, -3, @Date4_orig) as date), cast(dateadd(dd, -1, @Date4_orig) as date) )  -- Конец периода


DROP TABLE IF EXISTS #ids2;
SELECT ID
into #ids2
FROM  METAZON_RO.METAZON.dbo.DocumentLst D
WHERE D.ID IN (SELECT DISTINCT DocumentID FROM Reporting_DataMart.CCF.mb_CF_out_future p WHERE p.DocDate >= @Date3 AND p.DocDate <= @Date4)
AND D.Date >= @Date3
AND D.Date <= @Date4
AND (Descript LIKE '%Предоплата%'
     OR  Descript LIKE '%Prepayment%'
     OR  Descript LIKE '%Preayment%'
     OR  Descript LIKE '%VO11100%')
AND (Descript NOT LIKE '%удержана предоплата%' ) ;

DROP TABLE IF EXISTS #prep;
WITH A AS (
SELECT * FROM  #ids
UNION
SELECT * FROM  #ids2)
SELECT *
INTO #prep
FROM A;

DROP TABLE IF EXISTS #col;
SELECT DocumentID,
CASE WHEN p.DocumentID IN (SELECT * FROM #prep)
THEN 1
ELSE 0 END Prepayment_description
into #col
FROM Reporting_DataMart.CCF.mb_CF_out_future p;

DROP TABLE IF EXISTS  zzzTemp.futurePayments_new;
SELECT DISTINCT f.*,
                c.Prepayment_description
INTO zzzTemp.futurePayments_new
FROM Reporting_DataMart.CCF.mb_CF_out_future f
LEFT JOIN #col c ON c.DocumentID = f.DocumentID
WHERE f.DocumentID NOT IN (
            select f.DocumentID
            from  Reporting_DataMart.CCF.mb_CF_out_future f
            left join Reporting_DataMart.CCF.mb_CF_out_past p on f.DocumentID = p.DocumentID and abs(f.Amount) = abs(p.Amount)
            where DocumentState = 'Ожидает оплаты'
            and f.PaymentDate < GETDATE()
            and OperationType  not like '%реализации%'
            and f.DocumentType NOT IN ('Отчет о реализации комиссионного товара', 'Отчет о реализации','Оплата реализации')
            and p.DocumentID is not null);
            '''
    }
    print('Start executing past...')
    with pyodbc.connect(MSSQL_CONNECTION_STRING) as connection:
        connection.execute(sql['main'])
    print('Successfully executed past')
    print('Start executing future...')
    with pyodbc.connect(MSSQL_CONNECTION_STRING) as connection:
        connection.execute(sql['future'])
    print('Successfully executed future')
