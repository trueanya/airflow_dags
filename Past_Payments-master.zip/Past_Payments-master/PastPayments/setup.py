from setuptools import setup
setup(
    name='at.PastPayments',
    version='0.0.24',
    description='PastPayments for cashflow',
    url='https://gitlab.ozon.ru/cf_team/Past_Payments/PastPayments',
    author='atrukhova',
    author_email='atrukhova@ozon.ru',
    license='superlicense',
    namespace_packages=['at_PastPayments'],
    packages=['at_PastPayments'], # Для разделения использовать только нижнее подчеркивание
    install_requires=[
        'datetime',
        'pyodbc',
        'pandas',
        'numpy', 
        'sqlalchemy',
        'psycopg2',
        'pymssql==2.2.5',
        'python-rake'
    ],
    package_dir={"at_PastPayments": "data"}, # ключи словаря должны присутствовать в параметре packages (выше)
    keywords=['', ''],
)

