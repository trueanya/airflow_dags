sql = {
'docs': '''
        DROP TABLE IF EXISTS zzzTemp.Docs_wo_BU;
        WITH prep AS(
        SELECT DISTINCT DocumentID
        FROM  zzzTemp.futurePayments_new f
        WHERE  NewBU = 'wo BU' AND  PaymentDate >= '2020-01-01' AND PaymentDate <= (select max(PaymentDate) from zzzTemp.futurePayments_new)
        AND ContractType IN ('Договор закупки', 'Оплата по договорам цессии') --AND Type = 'Накладная закупки'
        AND Prepayment_description = 0),
        prep2 AS (SELECT DISTINCT ItemID,
                                  DocumentID,
                                  ROW_NUMBER() OVER (PARTITION BY DocumentID ORDER BY DocumentID) AS num
                  FROM METAZON_RO.Metazon.dbo.ItemPosition_New i
                  LEFT JOIN prep p ON p.DocumentID = i.Objectid
                  WHERE Objectid IN (SELECT * FROM prep)
                  )
        SELECT *
        INTO zzzTemp.Docs_wo_BU
        FROM prep2 WHERE num = 1;

        DROP TABLE IF EXISTS zzzTemp.items_wo_BU;
        select ObjectID,
               cast (SourceKey as int) as SourceKey
        into zzzTemp.items_wo_BU
        from METAZON_RO.Metazon.dbo.ObjectSource
        where ObjectID IN (SELECT DISTINCT ItemID from zzzTemp.Docs_wo_BU ) AND TableName = 'Item';
''',
'get_ids_from_ms': '''
                select * from zzzTemp.items_wo_BU;
                   ''',
'vertica': '''
            TRUNCATE TABLE  cf_team.at_doc_bu_future;
            INSERT INTO cf_team.at_doc_bu_future
            select distinct i.id as itemid,
                            cat1.Name AS BU
            FROM metazonbeeeye.Item i
            left join metazonbeeeye.ItemType it on it.ID = i.ItemTypeID
            left join (select ID, Name, Category1ID from metazonbeeeye.Category where level = 1) cat1 on cat1.ID = it.Category1ID
            WHERE i.id IN (SELECT distinct DocumentID FROM cf_team.at_docs_wo_bu_future)
            AND i.RezonItemID IN (SELECT distinct ItemID FROM cf_team.at_docs_wo_bu_future); 
            ''',
'select_vertica': '''
                SELECT * FROM cf_team.at_doc_bu_future;
                    ''',
'final' :   '''
            DROP TABLE IF EXISTS #docs_to_drop; -- тут находим айди, для которых удалось найти бю на вертике
            select DISTINCT DocumentID
            into #docs_to_drop
            from zzzTemp.Docs_wo_BU where ItemID in (select ItemID from  zzzTemp.at_item_bu_future);

            DROP TABLE IF EXISTS zzzTemp.future_Payments_NewBU;
            with prep as (
            select * from zzzTemp.futurePayments_new
            where DocumentID not in (select * from #docs_to_drop)
            UNION
            select
                PaymentDate,
                originalDocumentID,
                f1.DocumentID,
                DocumentType ,
                DocNum,
                DocDate ,
                DocumentState ,
                DocumentAmount,
                Currency  ,
                ContractType,
                Contract ,
                ContractID  ,
                Contragent,
                Payer  ,
                Category ,
                Prepayment  ,
                f2.BU,
                Amount ,
                f2.BU,
                AmountRub,
                Type ,
                Prepayment_description
             from zzzTemp.futurePayments_new f1
            left join zzzTemp.Docs_wo_BU d on d.DocumentID = f1.DocumentID
            left join zzzTemp.at_item_bu_future f2 on f2.itemid = d.ItemID
            WHERE f1.DocumentID in (select * from #docs_to_drop))
            select *
            into #final
            from prep;
            
            select *  
            into zzzTemp.future_Payments_NewBU
            from #final;
        ''',
}
