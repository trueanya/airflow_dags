def  new_bu(conn_info_ms, conn_info_vertica): 
    import pandas as pd
    import vertica_python
    import numpy as np
    from sqlalchemy import create_engine 
    import datetime
    import csv
    import pyodbc
    import sqlalchemy
    import pymssql
    from at_future_new_bu.queries import sql as sql
    from at_future_new_bu import functions as f
    import logging

    MSSQL_CONNECTION_STRING = f.get_ms_params(conn_info_ms)
    pyodbc_connection = pyodbc.connect(MSSQL_CONNECTION_STRING)
    ms_creds = f"mssql+pymssql://{conn_info_ms['user']}:{conn_info_ms['password']}@{conn_info_ms['host']}/zzzTemp"
    engine = create_engine(ms_creds)

    logging.info('Start finding docs mssql...')
    with pyodbc.connect(MSSQL_CONNECTION_STRING) as connection:
        connection.execute(sql['docs'])

    logging.info('Making df...')
    df = f.get_df_from_mssql(sql['get_ids_from_ms'], MSSQL_CONNECTION_STRING).rename(columns={0:'DocumentID', 1:'ItemID'})

    logging.info('Inserting into vertica...')
    table = 'cf_team.at_docs_wo_bu_future'
    f.insert_df_into_vertica(df, table, conn_info_vertica, df.columns)

    logging.info('Getting bu from vertica...')
    f.vertica_execute(sql['vertica'], conn_info_vertica)
    df2 = f.get_df_from_vertica(sql['select_vertica'], conn_info_vertica).rename(columns = {0:'itemid', 1: 'bu'})

    logging.info('Inserting to mssql new bus')
    table = 'zzzTemp.at_item_bu_future'
    f.insert_to_mssql(table, df2, engine)

    logging.info('Executing final')
    with pyodbc.connect(MSSQL_CONNECTION_STRING) as connection:
        connection.execute(sql['final'])
