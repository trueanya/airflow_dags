import pandas as pd
import vertica_python
import numpy as np
from sqlalchemy import create_engine 
import datetime
import csv
import pyodbc
import sqlalchemy
import pymssql
def get_ms_params(conn_info_ms):
    PARAMS = ['DRIVER={ODBC Driver 17 for SQL Server}',
                  'SERVER=bidb.o3.ru',  # укажите сервер, логин, пароль и базу данных
                  f'UID={conn_info_ms["user"]}',
                  f'PWD={conn_info_ms["password"]}',
                  'DATABASE=zzzTemp'
              ]

    MSSQL_CONNECTION_STRING = ';'.join(PARAMS)
    return MSSQL_CONNECTION_STRING


def insert_to_mssql(table, df, engine):
    # Deleting existing data in SQL Table:-
    engine.execute(f"DROP TABLE IF EXISTS {table}")
    
    print(table.split('.')[1],  table.split('.')[0])
    # upload the DataFrame
    df.to_sql('at_item_bu_future', engine,'zzzTemp',if_exists='append', index=False)

    print('Done')

    print("rows were inserted to mssql {}".format(table))


def get_df_from_mssql(SQL, MSSQL_CONNECTION_STRING):
    """
    Функция выполняет запрос mssql и возвразает DataFrame с результатом этого запроса
    """
    with pyodbc.connect(MSSQL_CONNECTION_STRING) as mssql_connection:
        mssql_cursor = mssql_connection.cursor()
        mssql_cursor.execute(SQL)
        mssql_data = mssql_cursor.fetchall()
    for i in range(0, len(mssql_data)):
        mssql_data[i] = tuple(mssql_data[i])
    df = pd.DataFrame(mssql_data)
    return df


def get_df_from_vertica(sql, conn_info_vertica):
        with vertica_python.connect(**conn_info_vertica) as vertica_connection:
            vertica_cursor = vertica_connection.cursor()
            vertica_cursor.execute(sql)
            vertica_data = vertica_cursor.fetchall()
            for i in range(0,len(vertica_data)):
                vertica_data[i]=tuple(vertica_data[i])
            vertica_df = pd.DataFrame(vertica_data)
            vertica_cursor.close()
            return vertica_df

            
def vertica_execute(sql : str, VERTICA_PARAMS):
    vertica_conn = vertica_python.connect(**VERTICA_PARAMS)
    cur = vertica_conn.cursor()
    try:
        runsql = cur.execute(sql)
    except Exception as e:
        exc = traceback.format_exc()
        log_entry('Ошибка при выполнении запроса на Vertica \n' + exc)
        print(log_entry)
        raise
    vertica_conn.commit()
    vertica_conn.close()

        
def insert_df_into_vertica(df : pd.DataFrame, table_name_vertica : str, conn_info, cols):
    with vertica_python.connect(**conn_info) as conn:
        cur = conn.cursor()
        cur.execute(f'TRUNCATE TABLE {table_name_vertica}')
    with vertica_python.connect(**conn_info) as conn:
        cur = conn.cursor()
        file_name = "/tmp/{0}_tmp.text".format(table_name_vertica.split('.')[1])
        df.to_csv(file_name, sep=";", header=False, index=False)
        print("Data was written to tmp csv file: {}".format(file_name))
        print("Copying data from local csv!")
        query = "COPY {0} ({1}) FROM LOCAL '{2}' DELIMITER';'".format(
            table_name_vertica, ",".join(cols), file_name)
        print(query)
        cur.execute(query)
        print("Rows loaded:", cur.fetchall())
        
