from setuptools import setup
setup(
    name='at.future.new.bu',
    version='0.0.23',
    description='getting bu for payments new way for cashflow',
    url='https://gitlab.ozon.ru/cf_team/Factoring/Factoring',
    author='atrukhova',
    author_email='atrukhova@ozon.ru',
    license='superlicense',
    namespace_packages=['at_future_new_bu'],
    packages=['at_future_new_bu'], # Для разделения использовать только нижнее подчеркивание
    install_requires=[
        'datetime',
        'pandas',
        'numpy', 
        'vertica_python',
        'sqlalchemy',
        'psycopg2',
        'pymssql == 2.2.5',
        'python-rake',
        'pyodbc'
        
    ],
    package_dir={"at_future_new_bu": "data"}, # ключи словаря должны присутствовать в параметре packages (выше)
    keywords=['', ''],
)
