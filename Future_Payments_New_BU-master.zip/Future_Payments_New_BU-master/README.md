# Future Payments New BU Дополнительный функционал по идентификации БЮ  
Гитлаб проекта: https://gitlab.ozon.ru/cf_team/Future_Payments_New_BU/-/blob/master/future/data/queries.py  
Даг:  гитлаб - https://gitlab.ozon.ru/atrukhova/airflow_dags_prod/-/blob/master/CF_team/CF_PastPayments.py   
 Airflow - https://hdp3-airflow.s.o3.ru/admin/airflow/tree?dag_id=CF_Payments таска newbu  
 ## Описание
БЮ в большинстве отчетов привязываются по логике, реализованной в построении таблицы CCF_team.mb_DocumentBUAmount_old https://gitlab.ozon.ru/ccf_scripts/ccf-nexus/-/tree/master/Efim_display_docs201/data и даг https://hdp3-airflow.s.o3.ru/admin/airflow/tree?dag_id=CCF_Efim_display_docs  
![image.png](./image.png)
Это более расширенная версия классического подхода через action. 
Но в action можно найти товары и соответственно документы, к которым они привязаны, только для товаров, с которыми произошло какое -то “движение”: перемещение между складами, реализация и т.д. Про типы движений можно почитать здесь https://confluence.o3.ru/pages/viewpage.action?pageId=224279829
В отчетах могут фигурировать счета и накладные на товар, который не подходит ни под один из типов движений в action: например, не доехал и считается недостачей. Тогда БЮ к таким документам не доедут. Так как в отчетах мы работаем с документами, а не с товарами, то нам нужно определить документы без бю и найти список товаров для них в метазоне. После этого создаем свзяку документ – айди товара и переливаем ее на вертику. На вертике находим бю через RezonItemID.

