import sqlalchemy 
from sqlalchemy import create_engine  
import pandas as pd
import numpy as np
import vertica_python
import clickhouse_driver as chd
from clickhouse_driver.client import Client
import sys
import pymssql
import os
#jfjf

target_table_past = 'CF_team.at_factoring_st1'
target_table_future = 'CF_team.at_factoring_st1_future'

def get_columns_from_table(target_table, sql, VERTICA_PARAMS):
    with vertica_python.connect(**VERTICA_PARAMS) as vertica_connection:
        get_cols = pd.read_sql(sql.format(target_table.split('.')[0], target_table.split('.')[1]), vertica_connection)
        cols_to_dict = get_cols.to_dict('records')
        cols_null = [int_value['name'] for int_value in cols_to_dict if 'int' in int_value['type'].lower()]
        return cols_null

def insert_df_into_vertica(df : pd.DataFrame, table_name_vertica : str, conn_info, cols,sql):
    with vertica_python.connect(**conn_info) as conn:
        cur = conn.cursor()
        cur.execute(sql.format(table_name_vertica))
        print('Table was trancated')
        file_name = "/tmp/{0}_tmp.text".format(table_name_vertica.split('.')[1])
        df.to_csv(file_name, sep=";", header=False, index=False)
        print("Data was written to tmp csv file: {}".format(file_name))
        print("Copying data from local csv!")
        query = "COPY {0} ({1}) FROM LOCAL '{2}' DELIMITER';'".format(
            table_name_vertica, ",".join(cols), file_name)
        print(query)
        cur.execute(query)
        print("Rows loaded:", cur.fetchall())


def vertica_execute(sqls, VERTICA_PARAMS):
    vertica_conn = vertica_python.connect(**VERTICA_PARAMS)
    cur = vertica_conn.cursor()
    try:
        for sql in sqls:
            runsql = cur.execute(sql)
    except Exception as e:
        exc = traceback.format_exc()
        log_entry('Ошибка при выполнении запроса на Vertica \n' + exc)
        print(log_entry)
        raise
    vertica_conn.commit()
    vertica_conn.close()


def get_df_from_vertica(sql: str, VERTICA_PARAMS) -> pd.DataFrame:
    """
    Функция для получения таблицы с вертики c подключением по pyodbc
    Параметры:
    sql (str) - запрос
    Возвращаемое значение (pd.DataFrame) : таблица с вертики
    """
    try:
        vertica_connection = vertica_python.connect(**VERTICA_PARAMS)
    except Exception as e:
        exc = traceback.format_exc()
        print('Ошибка подключения к Vertica \n' + exc)
        raise e
    try:
        df = pd.read_sql(sql, vertica_connection)
    except Exception as e:
        exc = traceback.format_exc()
        print('Ошибка выполнения запроса на Vertica \n' + exc)
        vertica_connection.commit()
        vertica_connection.close()
        raise e
    vertica_connection.commit()
    vertica_connection.close()
    return df

def insert_to_mssql(table, df, engine):
    # Deleting existing data in SQL Table:-
    engine.execute(f"DROP TABLE IF EXISTS {table}")

    # upload the DataFrame
    df.to_sql(table.split('.')[1], engine,table.split('.')[0],if_exists='append', index=False)

    print("rows were inserted to mssql {}".format(table))

