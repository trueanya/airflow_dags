
def factoring_future(conn_info_vertica, conn_info_ms):
    import pandas as pd
    import vertica_python
    import numpy as np
    from sqlalchemy import create_engine 
    import datetime
    import csv
    VERTICA_PARAMS = conn_info_vertica
    from at_factoring.queries import queries as queries
    from at_factoring  import funcs as f
 
    ms_creds = f"mssql+pymssql://{conn_info_ms['user']}:{conn_info_ms['password']}@{conn_info_ms['host']}/zzzTemp"
    engine = create_engine(ms_creds)
    #future step -------------------------------
    print('Getting data from mssql for future...') 
    df = pd.read_sql(queries['main_data_future'], engine)
    df.replace('(^\s+|\s+$)', '', regex=True, inplace=True)
    df.replace({np.NaN: None}, inplace=True)
    columns = f.get_columns_from_table(f.target_table_future, queries['get_columns_vertica'], conn_info_vertica)
    for int_col in columns:
        df[f'{int_col}'] = df[f'{int_col}'].astype('Int64')

    print('Inserting data into vertica future...')
    f.insert_df_into_vertica(df, f.target_table_future, conn_info_vertica, df.columns,queries['truncate_table'])

    print('Executing final query for past')
    f.vertica_execute(queries['final_vertica_future'], conn_info_vertica)
    df = f.get_df_from_vertica('SELECT * FROM CF_team.at_factoring_future',conn_info_vertica) 
    table = 'zzzTemp.Future_Factoring'
    f.insert_to_mssql(table, df, engine)

