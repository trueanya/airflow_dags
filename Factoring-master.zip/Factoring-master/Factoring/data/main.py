def factoring(conn_info_vertica, conn_info_ms):
    import pandas as pd
    import vertica_python
    import numpy as np
    from sqlalchemy import create_engine 
    import datetime
    import csv
    VERTICA_PARAMS = conn_info_vertica
    from at_factoring.queries import queries as queries
    from at_factoring  import funcs as f
 
    ms_creds = f"mssql+pymssql://{conn_info_ms['user']}:{conn_info_ms['password']}@{conn_info_ms['host']}/zzzTemp"
    engine = create_engine(ms_creds)
     
    print('Getting data from mssql for past...') 
    df = pd.read_sql(queries['main_data'], engine)
    df.replace('(^\s+|\s+$)', '', regex=True, inplace=True)
    df.replace({np.NaN: None}, inplace=True)
    columns = f.get_columns_from_table(f.target_table_past, queries['get_columns_vertica'], conn_info_vertica)
    for int_col in columns:
        df[f'{int_col}'] = df[f'{int_col}'].astype('Int64')

    print('Inserting data into vertica past...')
    f.insert_df_into_vertica(df, f.target_table_past, conn_info_vertica, df.columns,queries['truncate_table'])

    print('Executing final query for past')
    f.vertica_execute(queries['final_vertica'], conn_info_vertica)
    df = f.get_df_from_vertica('SELECT * FROM CF_team.at_factoring',conn_info_vertica) 
    table_past = 'zzzTemp.Past_Factoring'
    f.insert_to_mssql(table_past, df, engine)
    