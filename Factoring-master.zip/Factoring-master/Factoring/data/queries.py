queries = { 
"truncate_table": "TRUNCATE TABLE {}",
    
"insert_to_vertica": """
                     COPY {}"""+f"""
                     FROM STDIN DELIMITER '^' ENCLOSED BY '\' 
                     """,
"get_columns_vertica": """
                       SELECT column_name as name, data_type as type, is_nullable
                       FROM columns 
                       WHERE table_schema = '{}' AND table_name = '{}'
                       """,


'main_data' : '''
                SELECT
                        D.Date AS DocDate,
                        D.ID as DocumentID,
                        CASE WHEN D.ParentDocumentID IS NULL THEN D.ID ELSE D.ParentDocumentID END ParentDocID,
                        CASE WHEN OO.OwnerObjectID IS NULL THEN own.OwnerObjectID ELSE OO.OwnerObjectID END DocID,
                        O.AmountCurr AS AmountCurr_per_doc,
                        DD.AmountNDS,
                        O.AmountCurr -  DD.AmountNDS as AmountCurr_per_docz_wo_NDS,
                        OT.Name AS DocDescript,
                        NM.Name AS Contragent,
                        contr.Name AS Zakup,
                        contr.ID AS ContractID,
                        doc_state.Name AS Doc_state,
                        cast(e.Name as int) as Delays,
                        CASE WHEN datepart(dw,(dateadd(dd,cast(e.Name as numeric), D.Date))) = 7 THEN dateadd(dd, -1,(dateadd(dd,cast( e.Name as numeric) , D.Date)))
                             WHEN datepart(dw,(dateadd(dd,cast( e.Name as numeric) , D.Date))) = 1 THEN dateadd(dd, -2, (dateadd(dd,cast( e.Name as numeric) , D.Date)))
                        ELSE dateadd(dd,cast(e.Name as numeric), D.Date)
                        END Date_to_pay
                FROM  METAZON_RO.METAZON.dbo.Document D
                LEFT JOIN METAZON_RO.METAZON.dbo.Operation O ON D.ID = O.DocumentID
                LEFT JOIN METAZON_RO.METAZON.dbo.Object OO ON O.ID = OO.ID
                LEFT JOIN METAZON_RO.METAZON.dbo.Object OT ON OT.ID = OO.ObjectTypeID
                LEFT JOIN metazon_ro.metazon.dbo.Contract con ON D.ContractID = con.ID     -- доп таблица, PersonID - Альфа-Банк, АО
                LEFT JOIN METAZON_RO.METAZON.dbo.Object NM ON O.PersonID = NM.ID           -- Добавим контрагента (проверить)
                LEFT JOIN METAZON_RO.METAZON.dbo.Object contr ON O.ContractID = contr.ID   -- Добавим документ по договору закупки
                LEFT JOIN METAZON_RO.METAZON.dbo.Object own ON D.ID = own.ID               -- Добавим столбец OwnerObjectID (Накладная закупки)
                LEFT JOIN METAZON_RO.METAZON.dbo.Object doc_state ON own.StateID = doc_state.ID  -- Добавим столбец со статусом (данных стало меньше?)
                LEFT JOIN METAZON_RO.METAZON.dbo.ExtValue e ON e.OwnerObjectID =  contr.ID
                LEFT JOIN METAZON_RO.METAZON.dbo.Document DD ON DD.ID = COALESCE(own.OwnerObjectID,OO.OwnerObjectID) AND DD.AmountCurr = O.AmountCurr
                LEFT JOIN zzztemp.dbo.et_for_ppayments_future bu ON bu.DocumentID = D.ID
                WHERE e.ObjectTypeID = 11453709356000
                AND D.ContractID = 11236258016240
                AND D.Date >= '2022-07-01'
                and OT.Name = 'Выплата поставщику по факторингу'
                AND doc_state.Name != 'Отклонен';
                ''',

'final_vertica': [
''' --DROP TABLE IF EXISTS BU;
    CREATE LOCAL TEMPORARY TABLE BU ON COMMIT PRESERVE ROWS AS
        WITH Bu AS ( -- joining bu from vertica and getting not all of them
        WITH BU AS (
            SELECT *
            FROM  CCF_team.mb_DocumentBUAmount_old
            WHERE DocumentID IN (SELECT DISTINCT DocID FROM CF_team.at_factoring_st1)
            )
        SELECT  DISTINCT t1.*,
                        t2.BU,
                        t2.DocumentID as Doc2,
                        t2.IncomePrice
        FROM CF_team.at_factoring_st1 t1
        LEFT JOIN BU t2 ON t2.DocumentID  = t1.DocID)
        SELECT * FROM BU;
    ''',
'''--DROP TABLE IF EXISTS init;
CREATE LOCAL TEMPORARY TABLE init ON COMMIT PRESERVE ROWS AS
    SELECT COALESCE(DD.ParentDocumentID, D.ID) AS ParentDocumentID,
    D.ID AS DocID
    FROM metazonbeeeye.Document D
    LEFT JOIN metazonbeeeye.Document DD on DD.ID = D.ParentDocumentID
    WHERE D.ID IN (SELECT DISTINCT DocID FROM BU WHERE BU IS NULL);
''',
'''
--DROP TABLE IF EXISTS one_22;
CREATE LOCAL TEMPORARY TABLE one_22 ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT DocumentID,
                    itemid
    FROM  metazonbeeeye.action_2022
    WHERE  DocumentID IN (SELECT ParentDocumentID FROM init)  and SalesSchemaID = 11017671628710
    UNION
    SELECT DISTINCT DocumentID,
                    itemid
    FROM  metazonbeeeye.action_2021
    WHERE  DocumentID IN (SELECT ParentDocumentID FROM init)  and SalesSchemaID = 11017671628710
    order by itemid
    SEGMENTED BY HASH(itemid) ALL NODES;
''',
'''
--DROP TABLE IF EXISTS two_22;
CREATE LOCAL TEMPORARY TABLE two_22 ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT ID,
                    ItemTypeID
    FROM  metazonbeeeye.Item
    WHERE  ID IN (SELECT itemid FROM one_22) and SalesSchemaID = 11017671628710
    order by ID, ItemTypeID
    SEGMENTED BY HASH(ID,ItemTypeID) ALL NODES;
''',
'''
--DROP TABLE IF EXISTS four_22;
CREATE LOCAL TEMPORARY TABLE four_22 ON COMMIT PRESERVE ROWS AS
    SELECT ID,
        Name,
        Category1ID
    FROM metazonbeeeye.Category where level = 1
    ORDER BY ID
    SEGMENTED BY HASH(ID) ALL NODES;
''',
'''
--DROP TABLE IF EXISTS three_22;
CREATE LOCAL TEMPORARY TABLE three_22 ON COMMIT PRESERVE ROWS AS
    SELECT ID,
           Category1ID
    FROM metazonbeeeye.ItemType WHERE ID IN (SELECT ItemTypeID from two_22)
    ORDER BY ID, Category1ID
    SEGMENTED BY HASH(ID, Category1ID) ALL NODES;
''',
'''
--DROP TABLE IF EXISTS init2;
CREATE LOCAL TEMPORARY TABLE init2 ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT DocumentID,
                    cat1.Name
    FROM  one_22 a
    LEFT JOIN two_22 i ON i.id = a.itemid
    LEFT JOIN three_22 it ON it.ID = i.ItemTypeID
    LEFT JOIN four_22 cat1 ON cat1.ID = it.Category1ID;
''',

'''--DROP TABLE IF EXISTS final;
    CREATE LOCAL TEMPORARY TABLE final ON COMMIT PRESERVE ROWS AS
    WITH
    init1 AS (
        SELECT DISTINCT
                DocID,
                DocDate,
                SUM(IncomePrice) AS sum
        FROM BU
        GROUP BY DocID,
            DocDate
            ),
    init3 AS (SELECT DISTINCT BU.DocID,
                                BU.DocDate,
                                BU,
                                IncomePrice / sum AS perc
                FROM BU
                LEFT JOIN init1 ON BU.DocID = init1.DocID AND BU.DocDate = init1.DocDate),
    init4 AS (
                SELECT DISTINCT v.DocumentId,
                                BU.DocDate,
                                v.BU,
                                v.IncomePrice
                FROM  CCF_team.mb_DocumentBUAmount_old v
                JOIN init2 ON v.DocumentId = init2.DocumentID
                LEFT JOIN BU on BU.DocID = v.DocumentID
                WHERE BU.DocID is null
            ),
    init5 AS (
            SELECT BU.DocID,
                   BU.DocDate,
                   DocumentID,
                   ParentDocID,
                   AmountCurr_per_doc * perc AS AmountCurr_per_doc,
                   AmountNDS * perc  AS AmountNDS,
                   AmountCurr_per_docz_wo_NDS,
                   DocDescript,
                   Contragent,
                   Zakup,
                   ContractID,
                   Doc_state,
                   Delays,
                   Date_to_pay,
                   BU.BU
            FROM BU
            LEFT JOIN init3 ON BU.DocID = init3.DocID AND BU.BU = init3.BU
            WHERE BU.BU IS NOT NULL AND Doc_state = 'Оплачен'
            ),
        init6 AS (
        SELECT DISTINCT
                BU.DocID,
                BU.DocDate,
                BU.DocumentID,
                ParentDocID,
                AmountCurr_per_doc * coalesce(perc,1) AS AmountCurr_per_doc,
                AmountNDS * perc  AS AmountNDS,
                AmountCurr_per_docz_wo_NDS,
                DocDescript,
                Contragent,
                Zakup,
                ContractID,
                Doc_state,
                Delays,
                Date_to_pay,
                Name AS BU
        FROM init
        LEFT JOIN init2 ON init.ParentDocumentID = init2.DocumentID
        LEFT JOIN BU ON BU.DocID = init.DocID
        LEFT JOIN  init3 ON init3.DocID = init2.DocumentID AND init2.Name = init3.BU
        WHERE Doc_state = 'Оплачен' AND perc IS NOT NULL
        ORDER BY DocID
        ),
        init61 AS (
        SELECT DISTINCT
                DocumentID,
                count(Name) AS cnt
        from init2
        group by DocumentID
        ),
        init7 AS (
        SELECT DISTINCT
                BU.DocID,
                BU.DocDate,
                BU.DocumentID,
                ParentDocID,
                CASE WHEN v.BU IS NULL THEN  AmountCurr_per_doc * coalesce(perc,1/coalesce(cnt,1))
                    ELSE AmountCurr_per_doc * coalesce(perc,1) END AmountCurr_per_doc,
                v.IncomePrice,
                COALESCE(v.BU, init2.Name) as BU,
                AmountNDS * coalesce(perc,1/coalesce(cnt,1))  AS AmountNDS,
                AmountCurr_per_docz_wo_NDS,
                DocDescript,
                Contragent,
                Zakup,
                ContractID,
                Doc_state,
                Delays,
                Date_to_pay
        FROM init
        LEFT JOIN init2 ON init.ParentDocumentID = init2.DocumentID
        LEFT JOIN BU ON BU.DocID = init.DocID
        LEFT JOIN  init3 ON init3.DocID = init2.DocumentID AND init2.Name = init3.BU
        LEFT JOIN  CCF_team.mb_DocumentBUAmount_old v ON v.DocumentID = init.ParentDocumentID
        LEFT JOIN init61 i61 ON init.ParentDocumentID = i61.DocumentID
        WHERE Doc_state = 'Оплачен' AND perc IS  NULL
        ORDER BY DocID
        ),
        init8 AS (
            SELECT DISTINCT
                        DocID,
                        DocDate,
                        SUM(IncomePrice) AS sum
            FROM init7
            GROUP BY DocID,
                    DocDate

        ),
        init9 AS (
            SELECT DISTINCT init7.DocID,
                            init7.DocDate,
                            BU,
                            IncomePrice / sum AS perc
        FROM init7
        LEFT JOIN init8 ON init7.DocID = init8.DocID AND init7.DocDate = init8.DocDate
        ),
        init10 AS (
        SELECT DISTINCT
                init7.DocID,
                init7.DocDate,
                DocumentID,
                ParentDocID,
                AmountCurr_per_doc * coalesce(perc,1) AS AmountCurr_per_doc,
                AmountNDS * perc  AS AmountNDS,
                AmountCurr_per_docz_wo_NDS,
                DocDescript,
                Contragent,
                Zakup,
                ContractID,
                Doc_state,
                Delays,
                Date_to_pay,
                init7.BU
        FROM init7
        LEFT JOIN init9 ON init7.DocId = init9.DocId AND init7.DocDate = init9.DocDate AND init7.BU = init9.BU
        WHERE Doc_state = 'Оплачен'
        )
        SELECT * FROM init6
        UNION
        SELECT * FROM init5
        UNION
        SELECT * FROM init10;               
TRUNCATE TABLE CF_team.at_factoring;
INSERT INTO CF_team.at_factoring
SELECT * FROM  final;'''],

'main_data_future': '''
    SELECT
       D.ID as DocId,
       D.ObjectTypeName Тип_накладной,
       --D.ReceiverPersonID,
       NM.Name as Contragent,
       D.AmountCurr,
       D.AmountNDS,
       D.ContractID,
       D.AccountingDate as DocDate,
       ps.PaymentDate as PaymentDate,
       cast(e.Name as int) as Delays,
       CASE WHEN datepart(dw,(dateadd(dd,cast(e.Name as numeric),  ps.PaymentDate ))) = 7 THEN dateadd(dd, -1,(dateadd(dd,cast( e.Name as numeric) ,  ps.PaymentDate )))
             WHEN datepart(dw,(dateadd(dd,cast( e.Name as numeric) ,  ps.PaymentDate ))) = 1 THEN dateadd(dd, -2, (dateadd(dd,cast( e.Name as numeric) ,  ps.PaymentDate )))
       ELSE dateadd(dd,cast(e.Name as numeric),  ps.PaymentDate )
       END Date_to_pay,
       OO.NAME AS Status,
       OD.Name as Factoring
FROM METAZON_RO.METAZON.dbo.DocumentConsigLst D
LEFT JOIN METAZON_RO.METAZON.dbo.DocumentPaymentShedule ps ON PS.DocumentID = D.ID
LEFT JOIN  METAZON_RO.METAZON.dbo.Object O ON D.ID = O.ID
LEFT JOIN  METAZON_RO.METAZON.dbo.Object OO ON O.StateID = OO.ID
LEFT JOIN  METAZON_RO.METAZON.dbo.ObjectDirectoryLst OD ON D.ID = OD.ObjectID
LEFT JOIN  METAZON_RO.METAZON.dbo.Operation Op ON D.ID = Op.DocumentID
LEFT JOIN  METAZON_RO.METAZON.dbo.Object NM ON Op.PersonID = NM.ID
LEFT JOIN  METAZON_RO.METAZON.dbo.Object contr ON Op.ContractID = contr.ID
LEFT JOIN  METAZON_RO.METAZON.dbo.ExtValue e ON e.OwnerObjectID =  contr.ID
WHERE D.ID IN (SELECT ObjectID FROM METAZON_RO.METAZON.dbo.ObjectDirectoryLst WHERE Name LIKE '%Факторинг%')
AND D.Date > '2022-01-01'
AND OO.NAME != 'Оплачен'
AND OD.Name LIKE '%Факторинг%'
AND e.ObjectTypeID = 11453709356000;
''',

'final_vertica_future': 
[ '''DROP TABLE IF EXISTS BU;
     CREATE LOCAL TEMPORARY TABLE BU ON COMMIT PRESERVE ROWS AS
     WITH Bu AS ( -- joining bu from vertica and getting not all of them
        WITH BU AS (
                SELECT * FROM  CCF_team.mb_DocumentBUAmount_old
                WHERE DocumentID IN (SELECT DISTINCT DocID FROM CF_team.at_factoring_st1_future)
                )
        SELECT  DISTINCT t1.*,
                        t2.BU,
                        t2.DocumentID as Doc2,
                        t2.IncomePrice
        FROM CF_team.at_factoring_st1_future t1
        LEFT JOIN BU t2 ON t2.DocumentID  = t1.DocID)
    SELECT * FROM BU;
    ''',
'''DROP TABLE IF EXISTS init;
CREATE LOCAL TEMPORARY TABLE init ON COMMIT PRESERVE ROWS AS
SELECT COALESCE(DD.ParentDocumentID, D.ID) as ParentDocumentID,
       D.ID AS DocID
FROM metazonbeeeye.Document D
LEFT JOIN metazonbeeeye.Document DD on DD.ID = D.ParentDocumentID
WHERE D.ID IN (SELECT DISTINCT DocID FROM BU WHERE BU IS NULL);
''',
'''
DROP TABLE IF EXISTS one_22;
CREATE LOCAL TEMPORARY TABLE one_22 ON COMMIT PRESERVE ROWS AS
SELECT DISTINCT DocumentID,
                itemid
FROM  metazonbeeeye.action_2022
WHERE  DocumentID IN (SELECT ParentDocumentID FROM init)  and SalesSchemaID = 11017671628710
UNION
SELECT DISTINCT DocumentID,
                itemid
FROM  metazonbeeeye.action_2021
WHERE  DocumentID IN (SELECT ParentDocumentID FROM init)  and SalesSchemaID = 11017671628710
order by itemid
SEGMENTED BY HASH(itemid) ALL NODES;
''',
'''
DROP TABLE IF EXISTS two_22;
CREATE LOCAL TEMPORARY TABLE two_22 ON COMMIT PRESERVE ROWS AS
SELECT DISTINCT ID,
                ItemTypeID
FROM  metazonbeeeye.Item
WHERE  ID IN (SELECT itemid FROM one_22) and SalesSchemaID = 11017671628710
order by ID, ItemTypeID
SEGMENTED BY HASH(ID,ItemTypeID) ALL NODES;
''',
'''
DROP TABLE IF EXISTS four_22;
CREATE LOCAL TEMPORARY TABLE four_22 ON COMMIT PRESERVE ROWS AS
select ID,
       Name,
       Category1ID
FROM metazonbeeeye.Category where level = 1
order by ID
SEGMENTED BY HASH(ID) ALL NODES;
''',
'''
DROP TABLE IF EXISTS three_22;
CREATE LOCAL TEMPORARY TABLE three_22 ON COMMIT PRESERVE ROWS AS
select ID,
       Category1ID
FROM metazonbeeeye.ItemType WHERE ID IN (SELECT ItemTypeID from two_22)
order by ID,Category1ID
SEGMENTED BY HASH(ID, Category1ID) ALL NODES;
''',
'''
DROP TABLE IF EXISTS init2;
CREATE LOCAL TEMPORARY TABLE init2 ON COMMIT PRESERVE ROWS AS
SELECT DISTINCT DocumentID,
                cat1.Name
FROM  one_22 a
LEFT JOIN two_22 i ON i.id = a.itemid
LEFT JOIN three_22 it ON it.ID = i.ItemTypeID
LEFT JOIN four_22 cat1 ON cat1.ID = it.Category1ID;
''',

'''DROP TABLE IF EXISTS init2;
CREATE LOCAL TEMPORARY TABLE init2 ON COMMIT PRESERVE ROWS AS
SELECT DISTINCT DocumentID,
                cat1.Name
FROM  one_22 a
LEFT JOIN two_22 i ON i.id = a.itemid
LEFT JOIN three_22 it ON it.ID = i.ItemTypeID
LEFT JOIN four_22 cat1 ON cat1.ID = it.Category1ID
UNION
SELECT DISTINCT DocumentID,
                cat1.Name
FROM  one_21 a
LEFT JOIN two_21 i ON i.id = a.itemid
LEFT JOIN three_21 it ON it.ID = i.ItemTypeID
LEFT JOIN four_21 cat1 ON cat1.ID = it.Category1ID;
''',
'''DROP TABLE IF EXISTS final;
CREATE LOCAL TEMPORARY TABLE final ON COMMIT PRESERVE ROWS AS
WITH
init1 AS (
     SELECT DISTINCT
                   DocID,
                   DocDate,
                   SUM(IncomePrice) AS sum
     FROM BU
     GROUP BY DocID,
              DocDate
    ),
init3 AS (SELECT DISTINCT BU.DocID,
                          BU.DocDate,
                          BU,
                          IncomePrice / sum AS perc
         FROM BU
         LEFT JOIN init1 ON BU.DocID = init1.DocID AND BU.DocDate = init1.DocDate),
init4 AS (
        SELECT DISTINCT v.DocumentId,
                        BU.DocDate,
                        v.BU,
                        v.IncomePrice
        FROM  CCF_team.mb_DocumentBUAmount_old v
        JOIN init2 ON v.DocumentId = init2.DocumentID
        LEFT JOIN BU on BU.DocID = v.DocumentID
        WHERE BU.DocID is null
    ),
init5 AS (
     SELECT BU.DocID,
            BU.Тип_накладной,
            AmountCurr * perc AS AmountCurr,
            AmountNDS * perc  AS AmountNDS,
            AmountCurr * perc - AmountNDS * perc AS AmountCurr_wo_NDS,
            BU.ContractID,
            BU.DocDate,
            Date_to_pay,
            Delays,
            Status,
            Factoring,
            Contragent,
            BU.BU
    FROM BU
    LEFT JOIN init3 ON BU.DocID = init3.DocID AND BU.BU = init3.BU
    WHERE BU.BU IS NOT NULL
    ),
init6 AS (
SELECT DISTINCT
            BU.DocID,
            BU.Тип_накладной,
            AmountCurr * coalesce(perc,1) AS AmountCurr,
            AmountNDS * perc  AS AmountNDS,
            AmountCurr * coalesce(perc,1) - AmountNDS * perc AS AmountCurr_wo_NDS,
            BU.ContractID,
            BU.DocDate,
            Date_to_pay,
            Delays,
            Status,
            Factoring,
            Contragent,
            --Zakup,
            Name AS BU

FROM init
LEFT JOIN init2 ON init.ParentDocumentID = init2.DocumentID
LEFT JOIN BU ON BU.DocID = init.DocID
LEFT JOIN  init3 ON init3.DocID = init2.DocumentID AND init2.Name = init3.BU
WHERE perc IS NOT NULL
ORDER BY DocID
),
init7 AS (
SELECT DISTINCT
           BU.DocID,
           BU.DocDate,
           BU.Тип_накладной,
           --ParentDocID,
           AmountCurr * coalesce(perc,1) AS AmountCurr,
           v.IncomePrice,
           v.BU,
           AmountNDS * perc  AS AmountNDS,
           AmountCurr * coalesce(perc,1) - AmountNDS * perc AS AmountCurr_wo_NDS,
           --DocDescript,
           Contragent,
           --Zakup,
           ContractID,
           Status,
           Delays,
           Date_to_pay,
           Factoring
FROM init
LEFT JOIN init2 ON init.ParentDocumentID = init2.DocumentID
LEFT JOIN BU ON BU.DocID = init.DocID
LEFT JOIN  init3 ON init3.DocID = init2.DocumentID AND init2.Name = init3.BU
LEFT JOIN  CCF_team.mb_DocumentBUAmount_old v ON v.DocumentID = init.ParentDocumentID
WHERE  perc IS  NULL
ORDER BY DocID
),
init8 AS (
    SELECT DISTINCT
                   DocID,
                   DocDate,
                   SUM(IncomePrice) AS sum
     FROM init7
     GROUP BY DocID,
              DocDate

),
init9 AS (
    SELECT DISTINCT init7.DocID,
                    init7.DocDate,
                    BU,
                    IncomePrice / sum AS perc
FROM init7
LEFT JOIN init8 ON init7.DocID = init8.DocID AND init7.DocDate = init8.DocDate
),
init10 AS (
   SELECT DISTINCT
           init7.DocID,
           Тип_накладной,
           AmountCurr * coalesce(perc,1) AS AmountCurr,
           AmountNDS * coalesce(perc,1)  AS AmountNDS,
           AmountCurr_wo_NDS,
           ContractID,
           init7.DocDate,
           Date_to_pay,
           Delays,
           Status,
           Factoring,
           Contragent,
           init7.BU

FROM init7
LEFT JOIN init9 ON init7.DocId = init9.DocId AND init7.DocDate = init9.DocDate AND init7.BU = init9.BU
WHERE 1=1
)
SELECT * FROM init6
UNION
SELECT * FROM init5
UNION
SELECT * FROM init10;

TRUNCATE TABLE CF_team.at_factoring_future;
INSERT INTO CF_team.at_factoring_future
SELECT * FROM  final;
'''
]
}
