from setuptools import setup
setup(
    name='at.factoring',
    version='0.0.50',
    description='factoring for cashflow',
    url='https://gitlab.ozon.ru/cf_team/Factoring/Factoring',
    author='atrukhova',
    author_email='atrukhova@ozon.ru',
    license='superlicense',
    namespace_packages=['at_factoring'],
    packages=['at_factoring'], # Для разделения использовать только нижнее подчеркивание
    install_requires=[
        'datetime',
        'pandas',
        'numpy', 
        'vertica_python',
        'clickhouse_driver',
        'sqlalchemy',
        'psycopg2',
        'pymssql == 2.2.5',
        'python-rake',
        'openpyxl',
        'xlsxwriter'
    ],
    package_dir={"at_factoring": "data"}, # ключи словаря должны присутствовать в параметре packages (выше)
    keywords=['', ''],
)
